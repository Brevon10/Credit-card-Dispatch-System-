﻿using Microsoft.AspNetCore.Mvc;

namespace CardDispatch.Controllers
{
    public class CardStatusController : Controller
    {
        public IActionResult CardStatus()
        {
            return View("~/Views/Dashboard/CardStatus.cshtml");
        }
    }
}
