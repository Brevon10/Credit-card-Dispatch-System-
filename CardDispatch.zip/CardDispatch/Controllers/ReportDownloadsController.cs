﻿using Microsoft.AspNetCore.Mvc;
using CardDispatch.Models;
using System;

namespace CardDispatch.Controllers
{
    public class ReportDownloadsController : Controller
    {
        public IActionResult ReportDownloads()
        {
            var model = new CardDispatchModel
            {
                FromDate = DateTime.Parse("2004-08-02"),
                ToDate = DateTime.Parse("2024-08-02")
            };
            return View("~/Views/Dashboard/ReportDownloads.cshtml", model);
        }
    }
}
