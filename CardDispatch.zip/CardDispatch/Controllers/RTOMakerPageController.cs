﻿using Microsoft.AspNetCore.Mvc;
using CardDispatch.Models;
using System;

namespace CardDispatch.Controllers
{
    public class RTOMakerPageController : Controller
    {
        public IActionResult RTOMakerPage()
        {
            var model = new RTOProcess
            {
                MobileNo = "1234567890",
                EmailId = "abc@gmail.com",
                ApplicationNo = "0987654321",
                PANNo = "PAN123",
                CardAccountNo = "0007931567894562143",
                Name = "ABCDEF",
                Address = "Mumbai",
                CardNo = "4589",
                CourierName = "SpeedPost",
                TrackingNo = "JN598522020IN",
                DispatchDate = DateTime.Parse("2023-12-22"),
                CurrentStatus = "RTO",
                ReturnDates = new[] { DateTime.Now.AddDays(-10), DateTime.Now.AddDays(-5) },
                ReturnReasons = new[] { "Reason 1", "Reason 2" },
                ReDispatchDates = new[] { DateTime.Now },
                ReDispatchTrackNos = new[] { "RD123" },
                Action = "",
                Vendor = "Blue Dart",
                AWBNo = "31169651435",
                Remarks = ""
            };
            return View("~/Views/Dashboard/RTOMakerPage.cshtml", model);
        }
    }
}
