﻿using Microsoft.AspNetCore.Mvc;
using CardDispatch.Models;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;
using System.Text;

namespace CardDispatch.Controllers
{
    public class DashboardController : Controller
    {
        private readonly string _connectionString;

        public DashboardController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("OracleDb");
        }

        public IActionResult Index()
        {
            return View(new CardDispatchModel());
        }

        [HttpPost]
        public IActionResult Submit(CardDispatchModel model)
        {
            if (model.FromDate == default || model.ToDate == default)
            {
                ViewBag.Message = "Please provide valid dates!";
                return View("Index", model);
            }

            try
            {
                using (var connection = new OracleConnection(_connectionString))
                {
                    connection.Open();
                    using (var command = new OracleCommand("InsertCardDispatchData", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.Add("p_FromDate", OracleDbType.Date).Value = model.FromDate;
                        command.Parameters.Add("p_ToDate", OracleDbType.Date).Value = model.ToDate;
                        command.Parameters.Add("p_Region", OracleDbType.Varchar2).Value = model.Region ?? (object)DBNull.Value;
                        command.Parameters.Add("p_Logo", OracleDbType.Varchar2).Value = model.Logo ?? (object)DBNull.Value;
                        command.Parameters.Add("p_CampaignCode", OracleDbType.Varchar2).Value = model.CampaignCode ?? (object)DBNull.Value;
                        command.Parameters.Add("p_Status", OracleDbType.Varchar2).Value = model.Status ?? (object)DBNull.Value;
                        command.Parameters.Add("p_TotalCampaignCount", OracleDbType.Int32).Value = model.TotalCampaignCount;
                        command.Parameters.Add("p_Zone", OracleDbType.Varchar2).Value = model.Zone ?? (object)DBNull.Value;
                        command.Parameters.Add("p_ProductDescription", OracleDbType.Varchar2).Value = model.ProductDescription ?? (object)DBNull.Value;
                        command.Parameters.Add("p_ProductCode", OracleDbType.Varchar2).Value = model.ProductCode ?? (object)DBNull.Value;
                        command.Parameters.Add("p_AlphaCode", OracleDbType.Varchar2).Value = model.AlphaCode ?? (object)DBNull.Value;
                        command.Parameters.Add("p_BranchName", OracleDbType.Varchar2).Value = model.BranchName ?? (object)DBNull.Value;
                        command.Parameters.Add("p_TotalCount", OracleDbType.Int32).Value = model.TotalCount;

                        command.Parameters.Add("cur", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                        command.ExecuteNonQuery();
                    }
                }

                ViewBag.Message = "Data successfully inserted!";
            }
            catch (Exception ex)
            {
                ViewBag.Message = $"Error: {ex.Message}";
            }

            // Pass back the model to retain values
            return View("Index", model);
        }

        [HttpPost]
        public IActionResult DownloadCsv(CardDispatchModel model)
        {
            var csv = new StringBuilder();

            // CSV Header
            csv.AppendLine("FromDate,ToDate,Region,Logo,CampaignCode,Status,TotalCampaignCount,Zone,ProductDescription,ProductCode,AlphaCode,BranchName,TotalCount");

            // CSV Data
            csv.AppendLine($"{model.FromDate:yyyy-MM-dd},{model.ToDate:yyyy-MM-dd},{model.Region},{model.Logo},{model.CampaignCode},{model.Status},{model.TotalCampaignCount},{model.Zone},{model.ProductDescription},{model.ProductCode},{model.AlphaCode},{model.BranchName},{model.TotalCount}");

            byte[] buffer = Encoding.UTF8.GetBytes(csv.ToString());
            return File(buffer, "text/csv", "CardDispatchData.csv");
        }

        [HttpPost]
        public IActionResult Reset()
        {
            return RedirectToAction("Index");
        }
    }
}