﻿using Microsoft.AspNetCore.Mvc;
using CardDispatch.Models;
using System.Collections.Generic;

namespace CardDispatch.Controllers
{
    public class VendorController : Controller
    {
        private static readonly List<Vendor> Vendors = new List<Vendor>
        {
            new Vendor { VendorId = 1, VendorName = "Blue Dart" },
            new Vendor { VendorId = 2, VendorName = "SpeedPost" }
        };

        public IActionResult VendorIdMaster()
        {
            return View("~/Views/Dashboard/VendorIdMaster.cshtml", Vendors);
        }

        public IActionResult AddVendor()
        {
            return View("~/Views/Dashboard/AddVendor.cshtml");
        }

        [HttpPost]
        public IActionResult AddVendor(Vendor vendor)
        {
            if (ModelState.IsValid)
            {
                Vendors.Add(vendor);
                return RedirectToAction("VendorIdMaster");
            }
            return View("~/Views/Dashboard/AddVendor.cshtml", vendor);
        }
    }
}
