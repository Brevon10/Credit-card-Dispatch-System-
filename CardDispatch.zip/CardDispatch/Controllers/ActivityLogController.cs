﻿using Microsoft.AspNetCore.Mvc;
using CardDispatch.Models;
using System;
using System.Collections.Generic;

namespace CardDispatch.Controllers
{
    public class ActivityLogController : Controller
    {
        public IActionResult ActivityLog()
        {
            var logs = new List<ActivityLog>
            {
                new ActivityLog { LogDate = DateTime.Parse("2024-08-02"), ProcessType = "Sample", StatusDesc = "Sample Desc", Status = "Active", ProcessTime = DateTime.Now }
            };
            return View("~/Views/Dashboard/ActivityLog.cshtml", logs);
        }
    }
}
