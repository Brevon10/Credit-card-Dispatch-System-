﻿using Microsoft.AspNetCore.Mvc;

namespace CardDispatch.Controllers
{
    public class FileUploadController : Controller
    {
        public IActionResult FileUpload()
        {
            return View("~/Views/Dashboard/FileUpload.cshtml");
        }
    }
}
