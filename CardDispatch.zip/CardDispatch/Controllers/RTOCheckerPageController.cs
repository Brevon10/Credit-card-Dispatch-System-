﻿using Microsoft.AspNetCore.Mvc;
using CardDispatch.Models;
using System;

namespace CardDispatch.Controllers
{
    public class RTOCheckerPageController : Controller
    {
        public IActionResult RTOCheckerPage()
        {
            var model = new RTOProcess
            {
                FromDate = DateTime.Parse("2024-08-02"),
                ToDate = DateTime.Parse("2024-08-02")
            };
            return View("~/Views/Dashboard/RTOCheckerPage.cshtml", model);
        }
    }
}
