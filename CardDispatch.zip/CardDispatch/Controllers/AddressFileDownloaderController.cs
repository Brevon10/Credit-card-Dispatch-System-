﻿// Controller File: AddressFileDownloaderController.cs
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using Oracle.ManagedDataAccess.Client;
using CardDispatch.Models;
using Microsoft.Extensions.Configuration;

namespace CardDispatch.Controllers
{
    public class AddressFileDownloaderController : Controller
    {
        private readonly string _connectionString;

        public AddressFileDownloaderController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("OracleDb");
            if (string.IsNullOrEmpty(_connectionString))
            {
                // Consider logging this error as well
                throw new Exception("Connection string 'OracleDb' not found in configuration.");
            }
        }

        public IActionResult AddressFileDownloader()
        {
            return View("~/Views/Dashboard/AddressFileDownloader.cshtml");
        }

        [HttpPost]
        public IActionResult GetAddressData(DateTime reDispatchDate, string uniqueId, string recipientName, string address, string city, string state, string pincode)
        {
            List<AddressModel> addressList = new List<AddressModel>();

            using (OracleConnection connection = new OracleConnection(_connectionString))
            {
                try
                {
                    connection.Open();
                    using (OracleCommand command = new OracleCommand("GET_ADDRESS_DATA", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.Add("p_re_dispatch_date", OracleDbType.Date).Value = reDispatchDate;
                        command.Parameters.Add("p_unique_id", OracleDbType.Varchar2).Value = string.IsNullOrEmpty(uniqueId) ? (object)DBNull.Value : uniqueId;
                        command.Parameters.Add("p_recipient_name", OracleDbType.Varchar2).Value = string.IsNullOrEmpty(recipientName) ? (object)DBNull.Value : recipientName;
                        command.Parameters.Add("p_address", OracleDbType.Varchar2).Value = string.IsNullOrEmpty(address) ? (object)DBNull.Value : address;
                        command.Parameters.Add("p_city", OracleDbType.Varchar2).Value = string.IsNullOrEmpty(city) ? (object)DBNull.Value : city;
                        command.Parameters.Add("p_state", OracleDbType.Varchar2).Value = string.IsNullOrEmpty(state) ? (object)DBNull.Value : state;
                        command.Parameters.Add("p_pincode", OracleDbType.Varchar2).Value = string.IsNullOrEmpty(pincode) ? (object)DBNull.Value : pincode;
                        command.Parameters.Add("p_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                        using (OracleDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                addressList.Add(new AddressModel
                                {
                                    UniqueId = reader["UNIQUE_ID"].ToString(),
                                    RecipientName = reader["RECIPIENT_NAME"].ToString(),
                                    Address = reader["ADDRESS"].ToString(),
                                    City = reader["CITY"].ToString(),
                                    State = reader["STATE"].ToString(),
                                    Pincode = reader["PINCODE"].ToString(),
                                    ReDispatchDate = Convert.ToDateTime(reader["RE_DISPATCH_DATE"])
                                });
                            }
                        }
                    }
                }
                catch (OracleException ex)
                {
                    // Log the Oracle-specific error
                    Console.WriteLine($"Oracle Error fetching data: {ex.Message} (Code: {ex.Number})");
                    return Json(new { error = $"Error fetching data from the database: {ex.Message}" });
                }
                catch (Exception ex)
                {
                    // Log other potential errors


















































                    Console.WriteLine($"General Error fetching data: {ex.Message}");
                    return Json(new { error = "An unexpected error occurred while fetching data." });
                }
            }

            return Json(addressList);
        }
    }
}