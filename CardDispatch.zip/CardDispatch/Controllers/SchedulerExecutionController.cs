﻿using Microsoft.AspNetCore.Mvc;

namespace CardDispatch.Controllers
{
    public class SchedulerExecutionController : Controller
    {
        public IActionResult SchedulerExecution()
        {
            return View("~/Views/Dashboard/SchedulerExecution.cshtml");
        }
    }
}
