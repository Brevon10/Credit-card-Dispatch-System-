﻿using Microsoft.AspNetCore.Mvc;

namespace CardDispatch.Models
{
    public class RTOProcess
    {
        public string MobileNo { get; set; }
        public string EmailId { get; set; }
        public string ApplicationNo { get; set; }
        public string PANNo { get; set; }
        public string CardAccountNo { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        // Sub-section fields
        public string Name { get; set; }
        public string Address { get; set; }
        public string CardNo { get; set; }
        public string CourierName { get; set; }
        public string TrackingNo { get; set; }
        public DateTime DispatchDate { get; set; }
        public string CurrentStatus { get; set; }
        public DateTime[] ReturnDates { get; set; }
        public string[] ReturnReasons { get; set; }
        public DateTime[] ReDispatchDates { get; set; }
        public string[] ReDispatchTrackNos { get; set; }
        public string Action { get; set; }
        public string Vendor { get; set; }
        public string AWBNo { get; set; }
        public string Remarks { get; set; }
    }
}