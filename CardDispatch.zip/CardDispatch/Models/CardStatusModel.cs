﻿namespace CardDispatch.Models
{
    public class CardStatusModel
    {
        public string CardNumber { get; set; }
        public string Status { get; set; }
        public DateTime LastUpdated { get; set; }
        public string Remarks { get; set; }
    }
}
