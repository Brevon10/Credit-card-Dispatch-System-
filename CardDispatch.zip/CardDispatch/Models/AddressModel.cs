﻿namespace CardDispatch.Models
{
    public class AddressModel
    {
        public string UniqueId { get; set; }
        public string RecipientName { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Pincode { get; set; }
        public DateTime ReDispatchDate { get; set; }
    }
}
