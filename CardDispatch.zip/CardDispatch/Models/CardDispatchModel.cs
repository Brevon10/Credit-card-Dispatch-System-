﻿using Microsoft.AspNetCore.Mvc;

namespace CardDispatch.Models
{
    public class CardDispatchModel
    {
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public string Region { get; set; }
        public string Logo { get; set; }
        public string CampaignCode { get; set; }
        public string Status { get; set; }
        public int TotalCampaignCount { get; set; }
        public string Zone { get; set; }
        public string ProductDescription { get; set; }
        public string ProductCode { get; set; }
        public string AlphaCode { get; set; }
        public string BranchName { get; set; }
        public int TotalCount { get; set; }
    }
}