﻿using System;

namespace CardDispatch.Models
{
    public class ActivityLog
    {
        public DateTime LogDate { get; set; }
        public string ProcessType { get; set; }
        public string StatusDesc { get; set; }
        public string Status { get; set; }
        public DateTime ProcessTime { get; set; }
    }
}
