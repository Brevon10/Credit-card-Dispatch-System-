﻿namespace CardDispatch.Models
{
    public class SchedulerExecutionModel
    {
        public string TaskName { get; set; }
        public string Status { get; set; }
        public DateTime LastRunTime { get; set; }
        public string Remarks { get; set; }
    }
}
